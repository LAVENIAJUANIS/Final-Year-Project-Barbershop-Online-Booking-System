<style>
    #service-list tbody tr{
        cursor: pointer;
    }
</style>
<div class="py-3">
    <div class="card card-outline card-primary">
        <div class="card-header">
            <h5 class="card-title">Please Leave a Feedback</h5>
            <div class="card-tools">
                <button class="btn-primary" type="button" onclick="location.replace(document.referrer)"><i class="fa fa-angle-left"></i> Back</button>
            </div>
        </div>
        <div class="card-body">
            <div class="container-fluid">
                <form action="" id="appointment-form">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="fullname" class="control-label">Fullname</label>
                                <input type="text" name="fullname" id="fullname" class="form-control form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="contact" class="control-label">Contact </label>
                                <input type="text" name="contact" id="contact" class="form-control form-control" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="messages" class="control-label">Messages </label>
                                <input type="text" name="messages" id="messages" class="form-control form-control" rows="10" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-12 text-center">
                        <button class="btn btn-primary btn-lg rounded-0" type="submit">SEND</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    function calc(){
        var total = 0;
        $('.service_id:checked').each(function(){
            var cost = $('input[name="cost['+$(this).val()+']"]').val()
            total += parseFloat(cost)
        })
        $('#total_amount').text(parseFloat(total).toLocaleString('en-US',{style:"decimal", minimumFractionDigits: 2, maximumFractionDigits: 2}))
        $('[name="total"]').val(parseFloat(total))
    }
    $(function(){
        $('#service-list tbody tr').click(function(){
            if($(this).find('.service_id').is(":checked") == true){
                $(this).find('.service_id').prop("checked",false).trigger("change")
            }else{
                $(this).find('.service_id').prop("checked",true).trigger("change")
            }
            calc()
        })
       
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_appointment",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
                success:function(resp){
                    if(resp.status == 'success'){
                        uni_modal("Success","message.php")
                        $('#uni_modal').on('hide.bs.modal',function(e){
                            location.reload()
                        })
                        $('#uni_modal').on('shown.bs.modal',function(e){
                            end_loader();
                        })
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reason.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    end_loader();
                    $('html, body').animate({scrollTop:_this.offset().top},'fast')
                }
            })
        })
    })
</script>