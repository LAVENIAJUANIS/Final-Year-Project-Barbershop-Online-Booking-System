-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2023 at 12:36 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `msms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment_list`
--

CREATE TABLE `appointment_list` (
  `id` int(30) NOT NULL,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `schedule` date NOT NULL,
  `time` time NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `total` float NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL,
  `barber` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_list`
--

INSERT INTO `appointment_list` (`id`, `fullname`, `contact`, `email`, `schedule`, `time`, `status`, `total`, `date_created`, `date_updated`, `barber`) VALUES
(9, 'Petfyavey Jumun', '+0123456789', 'pet@gmail.com', '2023-02-17', '14:42:00', 1, 150, '2023-02-17 11:39:37', NULL, 'barber1'),
(11, 'lavenia', '+601248550929', 'laveniaajs@gmail.com', '2023-02-17', '15:47:00', 1, 150, '2023-02-17 12:45:11', NULL, 'barber1'),
(12, 'lavenia juanis', '0134678901', 'lav@gmail.com', '2023-02-17', '15:00:00', 1, 150, '2023-02-17 12:56:16', NULL, 'barber1'),
(13, 'Lejebit Joseph', '0148550929', 'lej@gmail.com', '2023-02-18', '14:00:00', 1, 250, '2023-02-17 12:58:18', NULL, 'barber3'),
(14, 'lavenia', '014678990', 'emi@gmail.com', '2023-02-28', '11:00:00', 0, 300, '2023-02-27 19:34:27', NULL, 'barber3');

-- --------------------------------------------------------

--
-- Table structure for table `appointment_service`
--

CREATE TABLE `appointment_service` (
  `appointment_id` int(30) NOT NULL,
  `service_id` int(30) NOT NULL,
  `cost` float NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `appointment_service`
--

INSERT INTO `appointment_service` (`appointment_id`, `service_id`, `cost`) VALUES
(9, 2, 150),
(11, 2, 150),
(12, 2, 150),
(14, 5, 300);

-- --------------------------------------------------------

--
-- Table structure for table `barber_list`
--

CREATE TABLE `barber_list` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barber_list`
--

INSERT INTO `barber_list` (`id`, `name`, `description`, `status`, `date_created`, `date_updated`) VALUES
(1, 'barber 1', 'female, 26, 5 year\'s experience', 1, '2023-02-17 03:57:06', '2023-02-17 03:57:06'),
(2, 'barber 2', 'male, 5 years experience', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'barber 3', 'male, 3 years experience, 23 years old', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'riri', 'Male, 28 years old , 6 years experience', 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `buy_list`
--

CREATE TABLE `buy_list` (
  `id` int(30) NOT NULL,
  `fullname` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `schedule` date NOT NULL,
  `time` time NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `total` float NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `fullname` text NOT NULL,
  `contact` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `messages` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `haircare_list`
--

CREATE TABLE `haircare_list` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `date_created` date NOT NULL,
  `date_updated` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `haircare_list`
--

INSERT INTO `haircare_list` (`id`, `name`, `description`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Hair Care Tips for Curly Hair', '1. Use oil \r\n2. Use moisturizing and sulfate-free shampoo\r\n3. Do not overcleanse your hair and rinse with cold water', 1, '2023-02-08', '00:00:00'),
(2, 'Hair Care Tips for Straight hair', '1. choose the right shampoos\r\n2. use the reverse washing method\r\n3. Use dry conditioner\r\n', 1, '0000-00-00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `hairproduct_list`
--

CREATE TABLE `hairproduct_list` (
  `p_id` int(11) NOT NULL COMMENT 'hair product id',
  `p_name` varchar(100) NOT NULL COMMENT 'hair product name',
  `p_cat` int(1) NOT NULL COMMENT 'hair product name',
  `p_price` float(8,2) NOT NULL,
  `p_img` varchar(255) NOT NULL,
  `p_availability` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hairproduct_list`
--

INSERT INTO `hairproduct_list` (`p_id`, `p_name`, `p_cat`, `p_price`, `p_img`, `p_availability`, `status`) VALUES
(1, 'L\'Oréal Professionnel Série Expert Vitamino Colour Shampoo 300ml', 1, 52.00, 'img/product/loreal-pro-vitamino-color-shampoo-300ml.jpg', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `hairstyle_list`
--

CREATE TABLE `hairstyle_list` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `date_created` date NOT NULL,
  `date_updated` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hairstyle_list`
--

INSERT INTO `hairstyle_list` (`id`, `name`, `description`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Hair style for girls', 'bob, layered,wolf cut', 1, '0000-00-00', '0000-00-00'),
(2, 'Hairstyle for men/boy', 'Fade haircut, Taper haircut, Buzz cut, Crew Cut', 1, '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `service_list`
--

CREATE TABLE `service_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_list`
--

INSERT INTO `service_list` (`id`, `name`, `description`, `cost`, `status`, `date_created`, `date_updated`) VALUES
(2, 'Hair Color', 'Hair Color', 150, 1, '2021-12-01 11:04:31', NULL),
(5, 'Scalp Massage & Conditioning Treatment', 'Scalp Massage & Conditioning Treatment', 300, 1, '2021-12-01 11:07:25', '2021-12-01 11:07:33'),
(6, 'Beard Sculpting', 'Beard Sculpting', 200, 1, '2021-12-01 11:07:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'BARBERSHOP ONLINE BOOKING SYSTEM'),
(6, 'short_name', 'BARBERSYSTEM'),
(11, 'logo', 'uploads/logo-1676437409.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1676437409.png'),
(15, 'content', 'Array'),
(16, 'email', 'info@barbers.com'),
(17, 'contact', '+6012567892'),
(18, 'from_time', '09:00'),
(19, 'to_time', '19:00'),
(20, 'address', 'Under the Tree, Here Street, There City, Anywhere 2306');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `status` int(1) NOT NULL DEFAULT 1 COMMENT '0=not verified, 1 = verified',
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `status`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', NULL, 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/avatar-1.png?v=1635556826', NULL, 1, 1, '2021-01-20 14:02:37', '2021-11-27 13:39:11'),
(3, 'John', NULL, 'Smith', 'jsmith', '1254737c076cf867dc53d60a0364f38e', 'uploads/avatar-3.png?v=1638343842', NULL, 2, 1, '2021-12-01 15:30:41', '2021-12-01 15:30:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment_list`
--
ALTER TABLE `appointment_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment_service`
--
ALTER TABLE `appointment_service`
  ADD KEY `appointment_id` (`appointment_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `barber_list`
--
ALTER TABLE `barber_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `haircare_list`
--
ALTER TABLE `haircare_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hairstyle_list`
--
ALTER TABLE `hairstyle_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_list`
--
ALTER TABLE `service_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment_list`
--
ALTER TABLE `appointment_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `barber_list`
--
ALTER TABLE `barber_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `haircare_list`
--
ALTER TABLE `haircare_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `hairstyle_list`
--
ALTER TABLE `hairstyle_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_list`
--
ALTER TABLE `service_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment_service`
--
ALTER TABLE `appointment_service`
  ADD CONSTRAINT `appointment_service_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `service_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `appointment_service_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointment_list` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
