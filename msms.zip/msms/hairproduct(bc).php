<head>
<title>msms</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/w3.css">
<!-- Load font and icon library -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<style>
    #service-list tbody tr{
        cursor: pointer;
    }
</style>

<div class="col-mid">
<div class="w3-row-padding w3-padding-16 w3-center" id="food">
<?php

$sql = "SELECT *
FROM hairproduct_list WHERE p_id AND p_availability = 1";


$service = mysqli_query($conn, $sql);

if (mysqli_num_rows($service) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($service)) {
	//echo "id: " . $row["p_id"]. " - Name: " . $row["p_name"]. " " . "<br>";
		
?>
	<!-- food resultset <a href="index.php?page=product&action=add&id=
	<?php //echo $row['p_id']; ?>"><i class="fa fa-shopping-cart" ></i> Add to Cart</a><br><br>-->
	<div class="w3-quarter">
	  <img src="<?php echo htmlentities($row['p_img']); ?>" style="width:100%"></img>
	  <b><?php echo htmlentities($row['p_name']);?></b><br>
	  RM <?php echo htmlentities($row['p_price']);?><br>	 
	 	<span class="fa fa-star checked"></span>
		<span class="fa fa-star checked"></span>
		<span class="fa fa-star checked"></span>
		<span class="fa fa-star"></span>
		<span class="fa fa-star"></span>	  
	<form method="post" action="buyproduct.php?action=add&id=<?php echo $row['p_id'];?>">
		<input type="text" name="quantity" value="1" size="2" />
		<button type="submit"><i class="fa fa-shopping-cart" style="font-size:20px"></i> Add to Cart</button>
	</form></b><br>
	</div>  
<?php 
	}//while
}//if
	else {
		echo "Sorry, 0 result found";
} 

mysqli_close($conn);
?>
	</div>
	</div>
</div>
<script>
    function calc(){
        var total = 0;
        $('.service_id:checked').each(function(){
            var cost = $('input[name="cost['+$(this).val()+']"]').val()
            total += parseFloat(cost)
        })
        $('#total_amount').text(parseFloat(total).toLocaleString('en-US',{style:"decimal", minimumFractionDigits: 2, maximumFractionDigits: 2}))
        $('[name="total"]').val(parseFloat(total))
    }
    $(function(){
        $('#service-list tbody tr').click(function(){
            if($(this).find('.service_id').is(":checked") == true){
                $(this).find('.service_id').prop("checked",false).trigger("change")
            }else{
                $(this).find('.service_id').prop("checked",true).trigger("change")
            }
            calc()
        })
        $('#appointment-form').submit(function(e){
            e.preventDefault();
            var _this = $(this)
            if($('.service_id:checked').length <=0){
                alert_toast("Please select atleast 1 service first.","warning")
                return false;
            }
            $('.pop-msg').remove()
            var el = $('<div>')
                el.addClass("pop-msg alert")
                el.hide()
            start_loader();
            $.ajax({
                url:_base_url_+"classes/Master.php?f=save_appointment",
				data: new FormData($(this)[0]),
                cache: false,
                contentType: false,
                processData: false,
                method: 'POST',
                type: 'POST',
                dataType: 'json',
				error:err=>{
					console.log(err)
					alert_toast("An error occured",'error');
					end_loader();
				},
                success:function(resp){
                    if(resp.status == 'success'){
                        uni_modal("Success","message.php")
                        $('#uni_modal').on('hide.bs.modal',function(e){
                            location.reload()
                        })
                        $('#uni_modal').on('shown.bs.modal',function(e){
                            end_loader();
                        })
                    }else if(!!resp.msg){
                        el.addClass("alert-danger")
                        el.text(resp.msg)
                        _this.prepend(el)
                    }else{
                        el.addClass("alert-danger")
                        el.text("An error occurred due to unknown reason.")
                        _this.prepend(el)
                    }
                    el.show('slow')
                    end_loader();
                    $('html, body').animate({scrollTop:_this.offset().top},'fast')
                }
            })
        })
    })
</script>