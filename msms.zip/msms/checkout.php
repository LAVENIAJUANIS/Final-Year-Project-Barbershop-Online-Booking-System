<?php
include("config.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="css/w3.css">
<link rel="stylesheet" type="text/css" href="css/mystyle.css">
<!-- Load font and icon library -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <style>
        .invoice-box {
            max-width: 800px;
            margin: auto;
            padding: 30px;
            border: 1px solid #eee;
            box-shadow: 0 0 10px rgba(0, 0, 0, .15);
            font-size: 16px;
            line-height: 24px;
            font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
            color: #555;
        }

        .invoice-box table {
            width: 100%;
            line-height: inherit;
            text-align: left;
        }

        .invoice-box table td {
            padding: 5px;
            vertical-align: top;
        }

        .invoice-box table tr td:nth-child(2) {
            text-align: right;
        }

        .invoice-box table tr.top table td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.top table td.title {
            font-size: 45px;
            line-height: 45px;
            color: #333;
        }

        .invoice-box table tr.information table td {
            padding-bottom: 40px;
        }

        .invoice-box table tr.heading td {
            background: #eee;
            border-bottom: 1px solid #ddd;
            font-weight: bold;
        }

        .invoice-box table tr.details td {
            padding-bottom: 20px;
        }

        .invoice-box table tr.item td {
            border-bottom: 1px solid #eee;
        }

        .invoice-box table tr.item.last td {
            border-bottom: none;
        }

        .invoice-box table tr.total td:nth-child(2) {
            border-top: 2px solid #eee;
            font-weight: bold;
        }

        @media only screen and (max-width: 600px) {
            .invoice-box table tr.top table td {
                width: 100%;
                display: block;
                text-align: center;
            }

            .invoice-box table tr.information table td {
                width: 100%;
                display: block;
                text-align: center;
            }
        }
    </style>
</head>

<body>
<!-- Page content row -->
<div class="row">
<div class="col-secLeft">
	<div class="header">
	<br><br><br>

<?php
if(isset($_SESSION["cart_item"])){
    $total_quantity = 0;
    $total = 0;
?>  


<table cellpadding="10" cellspacing="1" id="carttable" width="60%" style="margin: 0 10px 0 10px;">
<tbody>
<tr id="carttable tr">
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: left; background-color: #909090; color: white;">Item</th>
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: center; background-color: #909090; color: white;">Code</th>
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: center; background-color: #909090; color: white;" width="15%">Quantity</th>
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: center; background-color: #909090; color: white;" width="15%">Unit Price (RM)</th>
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: center; background-color: #909090; color: white;" width="15%">Price (RM)</th>
  <th style="padding-top: 12px; padding-bottom: 12px; text-align: center; background-color: #909090; color: white;" width="15%">Actions</th>
</tr> 

<?php   
foreach ($_SESSION["cart_item"] as $item){
  $item_price = $item["quantity"]*$item["price"];
  ?>
  <tr>
  <td id="#carttable td" style="text-align:left;"><?php echo $item["name"];?></td>        
  <td id="#carttable td" style="text-align:center;"><?php echo $item["prodID"]; ?></td>
  <td id="#carttable td" style="text-align:center;"><?php echo $item["quantity"]; ?></td>
  <td id="#carttable td" style="text-align:center;"><?php echo $item["price"]; ?></td>
  <td id="#carttable td" style="text-align:center;"><?php echo number_format($item,2); ?></td>
  <td id="#carttable td" style="text-align:center;"><a href="cart_action.php?action=remove&prodID=<?php echo $item["prodID"]; ?>"><i class="fa fa-times-circle" ></i> Remove</a></td>
  </tr>
  <?php
  $total_quantity += $item["quantity"];
  $total += ($item["price"]*$item["quantity"]);
  }
  ?>

<tr>
<td colspan="2" align="right"><b>Total:</b></td>
<td style="text-align:center;"><?php echo $total_quantity; ?></td>
<td style="text-align:center;" colspan="2"><strong><?php echo "RM ".number_format($total, 2); ?></strong></td>
</tr>
</tbody>
</table>  
 

<?php
} else {
?>
<p style="margin: 15px;">Your Cart is Empty</p>
<?php 
}
?>

<h1 class="text-center">
<td style="text-align:center;" colspan="2"><strong><?php echo "RM ".number_format($total, 2); ?></strong></td></h1>


<h5 class="text-center">including all service charges. (no delivery charges applied)</h5>
<br>

<div class="invoice-box">
<h2><center>CHECKOUT ORDER</center></h2>
    <table cellpadding="0" cellspacing="0">
        		<tr class="heading">
            <td>
                Payment Method
            </td>

        </tr>
		
		<tr>
		<td style="text-align:center;"><a href="onlinepay.php" class="btn btn-lg btn-block btn-primary"><button type="submit">Pay Online</button></a></td>
		<td style="text-align:center;"><a href="COD.php" class="btn btn-lg btn-block btn-primary"><button type="submit">COD</button></a></td>
				<td style="text-align:center;"><a href="cart_action.php" class="btn btn-lg btn-block btn-primary"><button type="submit">Go back to cart</button></a></td>
		</tr>

		
		
    </table>

</div>
        


<br><br><br><br><br><br>
        </body>


	</html>